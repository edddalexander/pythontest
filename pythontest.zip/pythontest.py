def my_function():
    """Returns a simple message."""
    return "Hello from the Python script!"


    # Call the function and print its return value
result = my_function()
print(result)
